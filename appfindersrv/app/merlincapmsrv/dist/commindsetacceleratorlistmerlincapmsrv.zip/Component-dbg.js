sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.mindset.accelerator.list.merlincapmsrv.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);