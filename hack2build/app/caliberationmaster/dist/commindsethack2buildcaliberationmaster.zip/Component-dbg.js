sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.mindset.hack2build.caliberationmaster.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);